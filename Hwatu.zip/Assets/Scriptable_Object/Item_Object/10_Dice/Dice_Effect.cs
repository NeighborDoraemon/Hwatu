using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Dice_Effect", menuName = "ItemEffects/Dice_Effect")]
public class Dice_Effect : ItemEffect
{
    public override void ApplyEffect(PlayerCharacter_Controller player)
    {
        player.has_Dice_Effect = true;
    }

    public override void RemoveEffect(PlayerCharacter_Controller player)
    {
        player.has_Dice_Effect = false;
    }
}
