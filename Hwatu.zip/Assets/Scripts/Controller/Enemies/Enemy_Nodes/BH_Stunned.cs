using MBT;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[AddComponentMenu("")]
[MBTNode("Enemy/BH_Stunned")]

public class BH_Stunned : Service
{
    public override void Task()
    {
        //throw new System.NotImplementedException();
    }

    //[SerializeField] 

    public override void OnEnter()
    {

    }
}
