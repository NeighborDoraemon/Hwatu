using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Enemy_Stun_Interface 
{
    public void Enemy_Stun(float Duration);
}
