using MBT;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Grenadier : Enemy_Parent, Enemy_Interface, Enemy_Stun_Interface
{
    [Header("Float Values")]
    

    [Header("Attack Delay")]
    [SerializeField] private float f_Before_Delay = 1.5f;
    [SerializeField] private float f_After_Delay = 2.0f;

    private float Attack_Time = 0.0f;

    [Header("BB_Value")]
    [SerializeField] private BoolReference BR_Chasing;
    //[SerializeField] private BoolReference BR_Facing_Left;
    [SerializeField] private BoolReference BR_Not_Attacking;

    [SerializeField] private FloatReference FR_Attack_Range;
    [SerializeField] private IntReference IR_Attack_Damage;
    //[SerializeField] private BoolReference BR_Stunned;

    [Header("Others")]
    //[SerializeField] private GameObject Target_Player;
    [SerializeField] private Animator Grenadier_Animator;

    [Header("Grenader")]
    [SerializeField] private Transform player;       // �÷��̾��� Transform
    [SerializeField] private Rigidbody2D grenade;   // ��ź�� Rigidbody2D
    [SerializeField] private float flightTime = 1f; // ��ź�� ��ǥ�� �����ϴ� �ð�
    [SerializeField] private float gravity = 9.8f;  // �߷� (Unity �⺻��)

    private bool is_Attack_Turn = false;
    private bool is_Attacking = false; // ���� �� ������ ����� ��, �ٸ� �ൿ�� ���ϰ� ����
    private bool is_Attack_Complete = false; // ���Ӱ����� ����

    public void Player_Initialize(PlayerCharacter_Controller player)
    {
        Target_Player = player.gameObject;
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!BR_Stunned.Value)
        {
            if (is_Attacking || BR_Chasing.Value)
            {
                Attack_Call();
            }
            else if (!BR_Chasing.Value)
            {
                Chasing();
            }
        }
    }

    private void Chasing()
    {
        //if (!is_Attacking)
        //{
        //    TurnAround();
        //}
    }

    private void Attack_Call()
    {
        Attack_Time += Time.deltaTime;
        TurnAround();
        if (!is_Attack_Turn) // ���� ���� ��, �÷��̾� ���� �����ϱ�
        {
            //TurnAround();
            Attack_Time = 0.0f;

            is_Attacking = true;
            is_Attack_Turn = true;
        }

        if (Attack_Time >= f_Before_Delay && !is_Attack_Complete) // Attack
        {
            //is_Attack_Turn = true;

            is_Attack_Complete = true;
            Grenadier_Animator.SetTrigger("is_Attacking");
            //Throw_Attack();
        }

        //Call After Delay Method
        if (Attack_Time >= f_Before_Delay + f_After_Delay)
        {
            is_Attack_Turn = false;
            is_Attacking = false;
            is_Attack_Complete = false;

            Attack_Time = 0.0f;
            BR_Not_Attacking.Value = true;
        }
    }

    public void Throw_Attack()
    {
        Vector2 startPosition = transform.position;          // ôź�� ��ġ
        Vector2 targetPosition = Target_Player.transform.position;            // �÷��̾� ��ġ
        Vector2 displacement = targetPosition - startPosition; // �Ÿ� ���

        float t = flightTime;                                // ���� �ð�
        float vx = displacement.x / t;                       // ���� �ӵ�
        float vy = (displacement.y + 0.5f * gravity * t * t) / t; // ���� �ӵ�

        Vector2 initialVelocity = new Vector2(vx, vy);       // �ʱ� �ӵ�
        Rigidbody2D grenadeInstance = Instantiate(grenade, startPosition, Quaternion.identity); // ��ź ����
        grenadeInstance.velocity = initialVelocity;          // �ӵ� �ο�
    }

    public void Enemy_Stun(float Duration)
    {
        is_Attack_Turn = false;
        is_Attacking = false;
        is_Attack_Complete = false;

        BR_Not_Attacking.Value = true;

        Attack_Time = 0.0f;

        Take_Stun(Duration);
    }
}
