using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Enemy_Interface
{
    void Player_Initialize(PlayerCharacter_Controller p_Controller);
    //public void Enemy_Stun(float Duration);
}
