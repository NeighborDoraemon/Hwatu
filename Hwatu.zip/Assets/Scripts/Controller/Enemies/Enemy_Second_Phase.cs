using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Enemy_Second_Phase
{
    void Call_Second_Phase();
}
