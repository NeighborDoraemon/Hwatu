using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Playables;

public class PlayerCharacter_Stat_Manager : MonoBehaviour
{
    public IAttack_Strategy attack_Strategy;
    public Weapon_Manager weapon_Manager;
    [HideInInspector] public Animator animator;

    [Header("�÷��̾� �⺻ �ɷ�ġ")]
    public float base_MovementSpeed = 1.0f;       // �÷��̾� �⺻ �̵��ӵ�
    public float base_JumpPower = 5.0f;           // �÷��̾� �⺻ ������
    public int base_Max_Health = 100;             // �÷��̾� �⺻ �ִ� ü��

    [Header("�÷��̾� ���� �ɷ�ġ")]
    public float movementSpeed = 1.0f;            // �̵��ӵ�
    public float jumpPower = 5.0f;                // ������
    public int max_Health = 100;                  // �ִ� ü��
    public int health = 100;                      // ü��
    public int attackDamage = 0;                  // �÷��̾� �߰� ���ݷ�
    public int skill_Damage = 0;                  // �߰� ��ų ���ݷ�
    public float crit_Rate = 0;                   // ġ��Ÿ Ȯ��
    public float crit_Dmg = 2;                    // ġ��Ÿ ����
    public int player_Life = 0;                   // �÷��̾� ���� ���

    [Header("�ɷ�ġ ���� �� ��ȭġ")]
    public float damage_Mul = 1.0f;               // �ִ� ������ ���� ����
    public float takenDamage_Mul = 1.0f;          // �޴� ������ ���� ����
    public float defend_Attack_Rate = 0.0f;       // ���� ���� ��� Ȯ��
    public float movementSpeed_Mul = 1.0f;        // �̵��ӵ� ���� ����
    //public float health_Mul = 1.0f;             // �ִ�ü�� ���� ����
    public float attack_Cooltime_Mul = 1.0f;      // ���ݼӵ� ��Ÿ�� ���� ����
    public float skill_Cooltime_Mul = 1.0f;       // ��ų ��Ÿ�� ���� ����
    public int damage_Reduce_Min = 0;             // ������ ���� �ּ�ġ
    public int damage_Reduce_Max = 0;             // ������ ���� �ִ�ġ
    public float heal_Amount_Mul = 1.0f;          // ȸ���� ���� ����
    public float money_Earned_Mul = 1.0f;         // �� ȹ�淮 ����
    public float teleport_Cooltime_Mul = 1.0f;    // �ڷ���Ʈ ��Ÿ�� ���� ����
    public float bleeding_Rate = 0.0f;            // ���� Ȯ��
    public int bleed_Damage = 2;                  // ���� ������
    public int bleed_Count = 5;                   // ���� ī��Ʈ
    public float bleed_Delay = 1.2f;              // ���� ���� ������
    public float stun_Rate = 0.0f;                // ���� Ȯ��

    [Header("���� ���� ����")]
    public float comboTime = 0.5f;
    public float attack_Cooldown = 1.0f;
    [HideInInspector] public float last_Attack_Time = 0f;
    [HideInInspector] public float last_ComboAttack_Time = 0f;
    public bool isAttacking = false;
    public int max_AttackCount = 0;
    public int es_Stack = 0;
    public bool has_Es_Extra_Life = false;

    [Header("���� ��ȭ ���� ����")]
    public float inhance_Skillcooltime_Value = 0.1f;
    public float teleport_Invicible_Time = 0.1f;

    [HideInInspector] public int cur_AttackInc_Phase = 1;
    [HideInInspector] public int cur_HealthInc_Phase = 1;
    [HideInInspector] public int cur_AttackCoolTimeInc_Phase = 1;
    [HideInInspector] public int cur_MoveSpeedInc_Phase = 1;

    [HideInInspector] public int cur_Inc_AttackDamage = 0;
    [HideInInspector] public int cur_Inc_Health = 0;
    [HideInInspector] public int cur_Inc_DamageReduction = 0;
    [HideInInspector] public float cur_Dec_AttackCoolTime = 0;
    [HideInInspector] public float cur_Inc_MoveSpeed = 0;

    [HideInInspector] public bool dmg_Inc_To_Lost_Health = false;
    [HideInInspector] public bool card_Match_Dmg_Inc = false;
    [HideInInspector] public bool skill_Cooltime_Has_Dec = false;
    [HideInInspector] public bool money_Earned_Has_Inc = false;
    [HideInInspector] public bool invicible_Teleport = false; 
    
    [Header("��ų ����")]
    public float skill_Cooldown = 1.0f;
    [HideInInspector]public float last_Skill_Time = 0f;
    public bool is_Skill_Active = false;

    [Header("�ڷ���Ʈ")]
    public int max_Teleport_Count = 1;
    public float teleporting_Distance = 3.0f;
    public float teleporting_CoolTime = 3.0f;

    [Header("Money")]
    public int i_Money = 0;
    public int i_Token = 0;

    [Header("UI_Text")]
    public TextMeshProUGUI money_Text;
    public TextMeshProUGUI token_Text;

    public Weapon_Data cur_Weapon_Data { get; private set; }

    public virtual void Set_Weapon(int weaponIndex)
    {
        Debug.Log($"���� �ε��� : {weaponIndex}�� ���� �õ�");

        Weapon_Data new_Weapon = weapon_Manager.Get_Weapon_Data(weaponIndex);

        if (new_Weapon != null)
        {            
            cur_Weapon_Data = new_Weapon;
        }

        //comb_Text.text = new_Weapon.comb_Name;
    }

    public void Increase_AttackDamage()
    {
        if (cur_AttackInc_Phase == 1)
        {
            if (cur_Inc_AttackDamage < 10)
            {
                cur_Inc_AttackDamage++;
                attackDamage += 1;
                Debug.Log("Attack Damage Enhanced (Phase 1) : Current Attack Damage " + attackDamage);
                return;
            }
        }

        if (cur_AttackInc_Phase == 1 && cur_Inc_AttackDamage >= 10)
        {
            cur_AttackInc_Phase = 2;
            Debug.Log("Phase 1 Completed. Phase 2 Start.");
        }

        if (cur_AttackInc_Phase == 2)
        {
            if (!dmg_Inc_To_Lost_Health)
            {
                dmg_Inc_To_Lost_Health = true;
                return;
            }
        }

        if (cur_AttackInc_Phase == 2 && dmg_Inc_To_Lost_Health)
        {
            cur_AttackInc_Phase = 3;

            card_Match_Dmg_Inc = true;
            return;
        }
    }

    public void Increase_Health()
    {
        if (cur_HealthInc_Phase == 1)
        {
            if (cur_Inc_Health < 50)
            {
                cur_Inc_Health += 5;
                max_Health += 5;
                health += 5;
                Debug.Log("Health Enhanced (Phase 1) : Current Max Health " + max_Health);
                return;
            }
        }

        if (cur_HealthInc_Phase == 1 && cur_Inc_Health >= 50)
        {
            cur_HealthInc_Phase = 2;
            Debug.Log("Phase 1 Completed. Phase 2 Start.");
        }

        if (cur_HealthInc_Phase == 2)
        {
            if (cur_Inc_DamageReduction < 3)
            {
                cur_Inc_DamageReduction += 1;
                damage_Reduce_Min += 1;
                damage_Reduce_Max += 1;
                Debug.Log("Health Enhanced (Phase 2) : Current DamageReduction " + damage_Reduce_Min + "," + damage_Reduce_Max);
                return;
            }
        }

        if (cur_HealthInc_Phase == 2 && cur_Inc_DamageReduction >= 3)
        {
            cur_HealthInc_Phase = 3;
            Debug.Log("Phase 2 Completed. Phase 3 Start.");

            heal_Amount_Mul += 0.2f;
            heal_Amount_Mul = Mathf.Round(heal_Amount_Mul * 100f) / 100f;

            return;
        }
    }

    public void Increase_AttackCoolTime()
    {
        if (cur_AttackCoolTimeInc_Phase == 1)
        {
            if (cur_Dec_AttackCoolTime < 1.0f)
            {
                cur_Dec_AttackCoolTime += 0.1f;
                attack_Cooltime_Mul -= 0.01f;
                attack_Cooltime_Mul = Mathf.Round(attack_Cooltime_Mul * 100f) / 100f;
                Debug.Log("Attack CoolTime Enhanced (Phase 1) : Current Attack CoolTime " + attack_Cooldown);
                return;
            }
        }

        if (cur_AttackCoolTimeInc_Phase == 1 && cur_Dec_AttackCoolTime >= 1.0f)
        {
            cur_AttackCoolTimeInc_Phase = 2;
            Debug.Log("Phase 1 Completed. Phase 2 Start.");
        }

        if (cur_AttackCoolTimeInc_Phase == 2)
        {
            if (!skill_Cooltime_Has_Dec)
            {
                skill_Cooltime_Mul -= inhance_Skillcooltime_Value;
                skill_Cooltime_Has_Dec = true;
                return;
            }
        }
        
        if (cur_AttackCoolTimeInc_Phase == 2 && skill_Cooltime_Has_Dec)
        {
            cur_AttackCoolTimeInc_Phase = 3;

            max_Teleport_Count++;
            return;
        }
    }

    public void Increase_MoveSpeed()
    {
        if (cur_MoveSpeedInc_Phase == 1)
        {
            if (cur_Inc_MoveSpeed < 1.0f)
            {
                cur_Inc_MoveSpeed += 0.1f;
                movementSpeed += 0.1f;

                movementSpeed = (float)Math.Round(movementSpeed, 1);
                cur_Inc_MoveSpeed = (float)Math.Round(cur_Inc_MoveSpeed, 1);
                Debug.Log("Move Speed Enhanced (Phase 1) : Current Move Speed " + movementSpeed);
                return;
            }
        }

        if (cur_MoveSpeedInc_Phase == 1 && cur_Inc_MoveSpeed >= 1.0f)
        {
            cur_MoveSpeedInc_Phase = 2;
            Debug.Log("Phase 1 Completed. Phase 2 Start.");
        }

        if (cur_MoveSpeedInc_Phase == 2)
        {
            if (!money_Earned_Has_Inc)
            {
                money_Earned_Mul += 0.2f;
                money_Earned_Has_Inc = true;
                return;
            }
            
        }
        
        if (cur_MoveSpeedInc_Phase == 2 && money_Earned_Has_Inc)
        {
            cur_MoveSpeedInc_Phase = 3;
            invicible_Teleport = true;
            return;
        }
    }
}
