using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ItemRarity
{
    Common,
    Epic,
    Legendary,
    Purification,
    Extinction
}