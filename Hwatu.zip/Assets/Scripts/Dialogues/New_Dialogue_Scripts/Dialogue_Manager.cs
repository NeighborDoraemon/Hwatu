using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UIElements;
using System.Linq;
using UnityEngine.UI;
using Unity.VisualScripting;
using UnityEngine.InputSystem.XR;

public class Dialogue_Manager : MonoBehaviour
{
    public static Dialogue_Manager instance;

    private Dictionary<int, Dialogue_Data> Dialogue_Dict = new Dictionary<int, Dialogue_Data>();
    private Dictionary<int, Item_Data> Item_Dict = new Dictionary<int, Item_Data>();

    private Queue<string> called_Name = new Queue<string>();
    private Queue<string> called_Script = new Queue<string>();
    private bool called_is_Choice;

    private Queue<string> called_Speaker = new Queue<string>();
    private Queue<string> called_Portrait = new Queue<string>();


    [Header("Objects")]
    [SerializeField] private Text Name_Text;
    [SerializeField] private Text Script_Text;
    [SerializeField] private GameObject Dialogue_Canvas;
    [SerializeField] private GameObject UI_Canvas;
    [SerializeField] private PlayerCharacter_Controller p_Controller;
    [SerializeField] private RawImage Portrait_Image;

    [Header("Choose Object")]
    [SerializeField] private GameObject Chose_Cursor_01;
    [SerializeField] private GameObject Chose_Cursor_02;
    [SerializeField] private GameObject Chose_Text_01;
    [SerializeField] private GameObject Chose_Text_02;
    [SerializeField] private GameObject Chose_Btn_01;
    [SerializeField] private GameObject Chose_Btn_02;

    private bool is_First_Chosing = true;   //Ŀ���� ��ġ true = 1��, false = 2��

    private GameObject Event_NPC;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        //Dialogue_Pharsing();
        StartCoroutine(Dialogue_Pharsing());
        Item_Pharsing();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //private void Dialogue_Pharsing()
    //{
    //    int? Lastkey = null;
    //    string path = Path.Combine(Application.streamingAssetsPath, "Hwatu_Dialogue" + ".csv"); // ���� �̸� �ֱ�


    //    if (!File.Exists(path))
    //    {
    //        Debug.LogError("Path File Missing!");
    //        return;
    //    }
    //    string[] Lines = File.ReadAllLines(path);

    //    for (int i = 1; i < Lines.Length; i++)
    //    {
    //        Dialogue_Data Temp_Data = new Dialogue_Data();

    //        string[] data = Lines[i].Split(',');

    //        if (!int.TryParse(data[0], out int Keyvalue))
    //        {
    //            Debug.LogError("Event Number Conversion Error!");
    //            return;
    //        }

    //        if (Lastkey == Keyvalue) //Ű�� �����ϴ� �ٷ� ���� �߰�
    //        {
    //            if (Dialogue_Dict.ContainsKey(Keyvalue))
    //            {
    //                Dialogue_Dict[Keyvalue].Character_Name.Add(data[1]);
    //                Dialogue_Dict[Keyvalue].Scripts.Add(ReplaceSpecialChars(data[2]));

    //                Dialogue_Dict[Keyvalue].Speaker.Add(data[4]);
    //                Dialogue_Dict[Keyvalue].Portrait.Add(data[5]);
    //            }
    //            else
    //            {
    //                Debug.LogError("Dictionary Error!");
    //                return;
    //            }
    //        }
    //        else
    //        {
    //            if (!Dialogue_Dict.ContainsKey(Keyvalue))   //Ű�� ������ ������Ű�� Ű���ְ�, �����ͳֱ�
    //            {
    //                Lastkey = Keyvalue;
    //                Temp_Data.Event_Num = Keyvalue;
    //                Temp_Data.Character_Name.Add(data[1]);
    //                Temp_Data.Scripts.Add(ReplaceSpecialChars(data[2]));

    //                bool.TryParse(data[3], out Temp_Data.is_Choice);    //bool ������ �Ľ� ������ ������ �Է�. ���н� false �Է�

    //                Temp_Data.Speaker.Add(data[4]);
    //                Temp_Data.Portrait.Add(data[5]);

    //                Dialogue_Dict.Add(Keyvalue, Temp_Data);
    //            }
    //        }
    //    }
    //}

    private IEnumerator Dialogue_Pharsing()
    {
        int? Lastkey = null;
        string path = Path.Combine(Application.streamingAssetsPath, "Hwatu_Dialogue.csv");

        string[] Lines;

#if UNITY_ANDROID
        UnityEngine.Networking.UnityWebRequest www = UnityEngine.Networking.UnityWebRequest.Get(path);
        yield return www.SendWebRequest();

        if (www.result != UnityEngine.Networking.UnityWebRequest.Result.Success)
        {
            Debug.LogError("Failed to load dialogue CSV: " + www.error);
            yield break;
        }

        Lines = www.downloadHandler.text.Split(new[] { '\n' }, System.StringSplitOptions.RemoveEmptyEntries);
#else
    if (!File.Exists(path))
    {
        Debug.LogError("Path File Missing!");
        yield break;
    }

    Lines = File.ReadAllLines(path);
#endif

        for (int i = 1; i < Lines.Length; i++)
        {
            Dialogue_Data Temp_Data = new Dialogue_Data();

            string[] data = Lines[i].Trim().Split(',');

            if (!int.TryParse(data[0].Trim(), out int Keyvalue))
            {
                Debug.LogError($"[Row {i}] Event Number Conversion Error: {data[0]}");
                continue;
            }

            if (Lastkey == Keyvalue)
            {
                if (Dialogue_Dict.ContainsKey(Keyvalue))
                {
                    Dialogue_Dict[Keyvalue].Character_Name.Add(data[1].Trim());
                    Dialogue_Dict[Keyvalue].Scripts.Add(ReplaceSpecialChars(data[2]));

                    Dialogue_Dict[Keyvalue].Speaker.Add(data[4].Trim());
                    Dialogue_Dict[Keyvalue].Portrait.Add(data[5].Trim());
                }
                else
                {
                    Debug.LogError($"[Row {i}] Key {Keyvalue} not found in dictionary.");
                    continue;
                }
            }
            else
            {
                if (!Dialogue_Dict.ContainsKey(Keyvalue))
                {
                    Lastkey = Keyvalue;
                    Temp_Data.Event_Num = Keyvalue;
                    Temp_Data.Character_Name.Add(data[1].Trim());
                    Temp_Data.Scripts.Add(ReplaceSpecialChars(data[2]));

                    bool.TryParse(data[3], out Temp_Data.is_Choice);

                    Temp_Data.Speaker.Add(data[4].Trim());
                    Temp_Data.Portrait.Add(data[5].Trim());

                    Dialogue_Dict.Add(Keyvalue, Temp_Data);
                }
            }
        }

        Debug.Log("Dialogue CSV Parsing Complete. Loaded Keys: " + Dialogue_Dict.Count);
    }
    private void Item_Pharsing()
    {
        int? Lastkey = null;
        string path = Path.Combine(Application.streamingAssetsPath, "Hwatu_Item_Table" + ".csv"); // ���� �̸� �ֱ�


        if (!File.Exists(path))
        {
            Debug.LogError("Path File Missing!");
            return;
        }
        string[] Lines = File.ReadAllLines(path);

        for (int i = 1; i < Lines.Length; i++)
        {
            Item_Data Temp_Data = new Item_Data();

            string[] data = Lines[i].Split(',');

            if (!int.TryParse(data[0], out int Keyvalue))
            {
                Debug.LogError("Item Index Error!");
                return;
            }

            if (Lastkey == Keyvalue) //Ű�� �����ϴ� �߰����� ���� (�������� �ߺ� ����)
            {
                //if (Item_Dict.ContainsKey(Keyvalue))
                //{
                //    Item_Dict[Keyvalue].Item.Add(data[1]);
                //    Item_Dict[Keyvalue].Scripts.Add(ReplaceSpecialChars(data[2]));
                //}
                //else
                {
                    Debug.LogError("Dictionary Error!");
                    return;
                }
            }
            else
            {
                if (!Dialogue_Dict.ContainsKey(Keyvalue))   //Ű�� ������ ������Ű�� Ű���ְ�, �����ͳֱ�
                {
                    Lastkey = Keyvalue;
                    Temp_Data.Item_Num = Keyvalue;
                    Temp_Data.Item_Name = data[1];
                    Temp_Data.Item_Dialogue = ReplaceSpecialChars(data[2]);
                    Temp_Data.Item_Effect_Script = ReplaceSpecialChars(data[3]);

                    //bool.TryParse(data[3], out Temp_Data.is_Choice);

                    Item_Dict.Add(Keyvalue, Temp_Data);
                }
            }
        }
    }

    public Item_Data Get_Item_Data(int Index)
    {
        return Item_Dict[Index];
    }

    private void Call_Dialogue(int Key)
    {
        called_Name.Clear();
        called_Script.Clear();
        called_Speaker.Clear();
        called_Portrait.Clear();

        foreach (string alpha in Dialogue_Dict[Key].Character_Name)
        {
            called_Name.Enqueue(alpha);
        }

        foreach (string beta in Dialogue_Dict[Key].Scripts)
        {
            called_Script.Enqueue(beta);
        }
        called_is_Choice = Dialogue_Dict[Key].is_Choice;

        foreach (string gamma in Dialogue_Dict[Key].Speaker)
        {
            called_Speaker.Enqueue(gamma);
        }

        foreach (string delta in Dialogue_Dict[Key].Portrait)
        {
            called_Portrait.Enqueue(delta);
        }
        Debug.Log("Speaker Count : " + called_Speaker.Count);
        Debug.Log("Portrait Count : " + called_Portrait.Count);

        Print_Next_Dialogue();
    }

    public void Print_Next_Dialogue()
    {
        if (called_Script.Count > 0)
        {
            Dialogue_Canvas.SetActive(true);
            UI_Canvas.SetActive(false);
            Name_Text.text = called_Name.Dequeue();
            Script_Text.text = called_Script.Dequeue();

            if (called_Portrait.Count > 0 && !string.IsNullOrEmpty(called_Portrait.Peek()))
            {
                Portrait_Image.gameObject.SetActive(true);
                string path = $"Portraits/{called_Speaker.Dequeue()}/{called_Portrait.Dequeue()}";
                Sprite portraitSprite = Resources.Load<Sprite>(path);

                if (portraitSprite != null)
                {
                    Portrait_Image.texture = portraitSprite.texture;
                }
                else
                {
                    Debug.LogError($"Portrait not found at path: {path}");
                    Portrait_Image.gameObject.SetActive(false);
                }
            }
            else
            {
                Portrait_Image.gameObject.SetActive(false);
                Debug.Log("There's no portrait for this dialogue or the portrait is empty.");
            }
            //Portrait_Image.texture = Resources.Load<Texture2D>("Portraits/" + called_Portrait.Dequeue());
        }
        else    //��ȭ �Ϸ� ���� ������ ���๮ (������ �ִ��� �˻� �ʿ�!!) else if�� �����ϰ� �̰� ������ ������ else�� ����
        {
            if (called_is_Choice)   //������ ����
            {
                //������ pc����
                Chose_Text_01.SetActive(true);
                Chose_Text_02.SetActive(true);
                Chose_Cursor_01.SetActive(true);

                // ������ ����� ����
                //Chose_Btn_01.SetActive(true);
                //Chose_Btn_02.SetActive(true);

                p_Controller.State_Change(PlayerCharacter_Controller.Player_State.Dialogue_Choice);

                is_First_Chosing = true;
            }
            else
            {
                Dialogue_Canvas.SetActive(false);
                UI_Canvas.SetActive(true);
                Event_NPC.GetComponent<Npc_Interface>().Npc_Interaction_End();
            }
        }
    }
    public void Chose_Cursor_Move()
    {
        if (is_First_Chosing)
        {
            Chose_Cursor_01.SetActive(false);
            Chose_Cursor_02.SetActive(true);
            is_First_Chosing = false;
        }
        else
        {
            Chose_Cursor_01.SetActive(true);
            Chose_Cursor_02.SetActive(false);
            is_First_Chosing = true;
        }

        Chose_Btn_01.SetActive(false);
        Chose_Btn_02.SetActive(false);
    }

    public void Start_Dialogue(int Num)
    {
        Call_Dialogue(Num);
        Dialogue_Canvas.SetActive(true);
        UI_Canvas.SetActive(false);

        Chose_Text_01.SetActive(false);
        Chose_Text_02.SetActive(false);
        Chose_Cursor_01.SetActive(false);
        Chose_Cursor_02.SetActive(false);
    }

    public void Btn_Choice_Accept()
    {
        is_First_Chosing = true;
        Chose_Btn_01.SetActive(false);
        Chose_Btn_02.SetActive(false);
        Chose_Complete();
    }

    public void Btn_Choice_Cancel()
    {
        is_First_Chosing = false;
        Chose_Btn_01.SetActive(false);
        Chose_Btn_02.SetActive(false);
        Chose_Complete();
    }

    public void Chose_Complete()
    {
        if (is_First_Chosing)
        {
            Debug.Log("First Choice Debug");
            Event_NPC.GetComponent<Npc_Interface>().Event_Start();
        }
        else
        {
            Debug.Log("Second Choice Debug");
            Event_NPC.GetComponent<Npc_Interface>().Npc_Interaction_End();
        }
        Dialogue_Canvas.SetActive(false);
        UI_Canvas.SetActive(true);
    }

    public void Get_Npc_Data(GameObject npc)
    {
        Event_NPC = npc;
    }

    // ��ȣ�� �޸��� ��ȯ�ϴ� �޼��� �߰�
    private string ReplaceSpecialChars(string input)
    {
        return input.Replace("^", ",");
                    //.Replace("��", ",")
                    //.Replace("//", ",");
    }
}

public class Dialogue_Data
{
    public int Event_Num;

    public List<string> Character_Name = new List<string>();
    public List<string> Scripts = new List<string>();

    public bool is_Choice;

    public List<string> Speaker = new List<string>();
    public List<string> Portrait = new List<string>();
}

public class Item_Data
{
    public int Item_Num;

    public string Item_Name;
    public string Item_Dialogue;
    public string Item_Effect_Script;
}