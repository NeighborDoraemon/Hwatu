using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;

public class Crash_Dialogue : MonoBehaviour, Npc_Interface
{
    [SerializeField] private int dialogue_Index;
    [SerializeField] private int Print_time = 1;
    private PlayerCharacter_Controller p_Controller;

    [Header("Cards")]
    [SerializeField] private bool give_Card = false;
    [SerializeField] private bool take_Card = false;

    public void Event_Attack(InputAction.CallbackContext ctx){}
    public void Event_Move(InputAction.CallbackContext ctx){}
    public void Event_Move_Direction(Vector2 dir){}

    public void Event_Start()
    {
    }

    public void Npc_Interaction_End()
    {
        if(p_Controller == null) { return; }
        p_Controller.State_Change(PlayerCharacter_Controller.Player_State.Normal);

        if (give_Card)
        {
            if (Object_Manager.instance == null)
            {
                Debug.LogError("Card Box���� Card_Spawner �ν��Ͻ� ����");
                return;
            }

            int spawnCount = 2;

            for (int i = 0; i < spawnCount; i++)
            {
                GameObject spawned_Card = Object_Manager.instance.Spawn_Cards(this.transform.position);

                if (spawned_Card != null)
                {
                    p_Controller.AddCard(spawned_Card);
                }
            }
            return;
        }

        if (take_Card)
        {
            p_Controller.Recall_All_Cards();
            return;
        }
    }

    public void Npc_Interaction_Start()
    {
        if(p_Controller == null) { return; }
        p_Controller.State_Change(PlayerCharacter_Controller.Player_State.Dialogue);
        // Set player stop move
        p_Controller.Player_Vector_Stop();
        Dialogue_Manager.instance.Start_Dialogue(dialogue_Index);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            Print_time--;
            if (Print_time < 0) { return; }
            p_Controller = collision.GetComponent<PlayerCharacter_Controller>();
            Dialogue_Manager.instance.Get_Npc_Data(this.gameObject);
            Npc_Interaction_Start();
        }
    }

    public void Reset_value()
    {
               Print_time = 1;
    }
}
