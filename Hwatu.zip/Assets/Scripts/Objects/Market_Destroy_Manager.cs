using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Market_Destroy_Manager
{
    public static System.Action<GameObject> On_Item_Destroyed;
}
